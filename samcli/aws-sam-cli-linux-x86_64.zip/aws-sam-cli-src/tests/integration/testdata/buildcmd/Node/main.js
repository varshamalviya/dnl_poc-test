
exports.lambdaHandler = async (event, context) => {
    return 'Hello World'
};

exports.secondLambdaHandler = async (event, context) => {
    return 'Hello Mars'
};