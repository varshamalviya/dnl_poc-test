def hanler(event, context):
    return "Hello World"

